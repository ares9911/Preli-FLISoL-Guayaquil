# Explosion Pro App

Aplicación web profesional con animación de explosión usando HTML5 Canvas.

## Características

- Cuenta regresiva
- Bomba animada
- Explosión con partículas
- Humo
- Onda expansiva
- Pantalla final
- Docker + Nginx
- Sin dependencias externas

## Ejecutar localmente con Docker

```bash
docker build -t explosion-pro-app .
docker run -d --name explosion-pro-app -p 8080:80 explosion-pro-app
```

Abrir en el navegador:

```text
http://localhost:8080
```

## Detener y eliminar contenedor

```bash
docker stop explosion-pro-app
docker rm explosion-pro-app
```

## Reconstruir después de cambios

```bash
docker build --no-cache -t explosion-pro-app .
docker rm -f explosion-pro-app
docker run -d --name explosion-pro-app -p 8080:80 explosion-pro-app
```

## Estructura

```text
explosion-pro-app/
├── Dockerfile
├── nginx.conf
├── README.md
└── app/
    ├── index.html
    ├── style.css
    └── script.js
```
