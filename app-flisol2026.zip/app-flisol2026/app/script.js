const canvas = document.getElementById("scene");
const ctx = canvas.getContext("2d");
const startBtn = document.getElementById("startBtn");
const resetBtn = document.getElementById("resetBtn");
const countdownEl = document.getElementById("countdown");
const finalMessage = document.getElementById("finalMessage");
const statusText = document.getElementById("statusText");

let width = 0;
let height = 0;
let particles = [];
let smoke = [];
let shockwaves = [];
let running = false;
let exploded = false;

function resize() {
  width = canvas.width = canvas.offsetWidth * window.devicePixelRatio;
  height = canvas.height = canvas.offsetHeight * window.devicePixelRatio;
  ctx.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
  width = canvas.offsetWidth;
  height = canvas.offsetHeight;
}

window.addEventListener("resize", resize);
resize();

function createParticle(x, y) {
  const angle = Math.random() * Math.PI * 2;
  const speed = 3 + Math.random() * 12;

  return {
    x,
    y,
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    radius: 2 + Math.random() * 7,
    life: 80 + Math.random() * 50,
    maxLife: 130,
    gravity: 0.08 + Math.random() * 0.08
  };
}

function createSmoke(x, y) {
  return {
    x: x + (Math.random() - 0.5) * 90,
    y: y + (Math.random() - 0.5) * 70,
    vx: (Math.random() - 0.5) * 1.8,
    vy: -0.6 - Math.random() * 1.8,
    radius: 18 + Math.random() * 45,
    life: 120 + Math.random() * 80,
    opacity: 0.28 + Math.random() * 0.25
  };
}

function drawBackground() {
  const gradient = ctx.createRadialGradient(width * 0.62, height * 0.42, 80, width * 0.62, height * 0.42, width);
  gradient.addColorStop(0, "#22384d");
  gradient.addColorStop(0.5, "#111827");
  gradient.addColorStop(1, "#030712");

  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = "rgba(255,255,255,0.04)";
  for (let i = 0; i < 80; i++) {
    const x = (i * 97) % width;
    const y = (i * 53) % height;
    ctx.beginPath();
    ctx.arc(x, y, 1.2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawBomb() {
  if (exploded) return;

  const x = width / 2;
  const y = height / 2 + 80;

  ctx.save();
  ctx.translate(x, y);

  ctx.fillStyle = "#0d1117";
  ctx.beginPath();
  ctx.arc(0, 0, 76, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "rgba(255,255,255,0.18)";
  ctx.lineWidth = 6;
  ctx.stroke();

  ctx.fillStyle = "#1f2937";
  ctx.fillRect(-18, -98, 36, 34);

  ctx.strokeStyle = "#ffcc80";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(0, -98);
  ctx.bezierCurveTo(30, -145, 82, -126, 82, -176);
  ctx.stroke();

  ctx.fillStyle = "#ff7043";
  ctx.beginPath();
  ctx.arc(82, -180, 10 + Math.sin(Date.now() / 120) * 3, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "rgba(255,255,255,0.12)";
  ctx.beginPath();
  ctx.arc(-28, -24, 18, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function explode() {
  exploded = true;
  statusText.textContent = "Explosión ejecutada";

  const x = width / 2;
  const y = height / 2 + 55;

  shockwaves.push({ x, y, radius: 20, opacity: 1 });

  for (let i = 0; i < 260; i++) {
    particles.push(createParticle(x, y));
  }

  for (let i = 0; i < 80; i++) {
    smoke.push(createSmoke(x, y));
  }

  setTimeout(() => {
    finalMessage.classList.remove("hidden");
  }, 2300);
}

function updateAndDrawEffects() {
  shockwaves.forEach((wave) => {
    wave.radius += 12;
    wave.opacity -= 0.018;

    ctx.strokeStyle = `rgba(255, 214, 102, ${wave.opacity})`;
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(wave.x, wave.y, wave.radius, 0, Math.PI * 2);
    ctx.stroke();
  });

  shockwaves = shockwaves.filter(w => w.opacity > 0);

  particles.forEach((p) => {
    p.x += p.vx;
    p.y += p.vy;
    p.vy += p.gravity;
    p.life--;

    const alpha = Math.max(p.life / p.maxLife, 0);
    const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.radius * 3);
    gradient.addColorStop(0, `rgba(255,255,255,${alpha})`);
    gradient.addColorStop(0.25, `rgba(255,214,102,${alpha})`);
    gradient.addColorStop(0.7, `rgba(255,112,67,${alpha * 0.9})`);
    gradient.addColorStop(1, `rgba(120,40,20,0)`);

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.radius * 3, 0, Math.PI * 2);
    ctx.fill();
  });

  particles = particles.filter(p => p.life > 0);

  smoke.forEach((s) => {
    s.x += s.vx;
    s.y += s.vy;
    s.life--;

    const alpha = Math.max((s.life / 200) * s.opacity, 0);
    ctx.fillStyle = `rgba(120, 120, 120, ${alpha})`;
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
    ctx.fill();
  });

  smoke = smoke.filter(s => s.life > 0);
}

function animate() {
  drawBackground();
  drawBomb();
  updateAndDrawEffects();
  requestAnimationFrame(animate);
}

function startSequence() {
  if (running) return;

  running = true;
  exploded = false;
  finalMessage.classList.add("hidden");
  particles = [];
  smoke = [];
  shockwaves = [];
  statusText.textContent = "Secuencia iniciada";

  let count = 5;
  countdownEl.textContent = count;
  countdownEl.classList.remove("hidden");

  const timer = setInterval(() => {
    count--;
    countdownEl.textContent = count;

    if (count <= 0) {
      clearInterval(timer);
      countdownEl.classList.add("hidden");
      explode();
    }
  }, 1000);
}

function resetScene() {
  running = false;
  exploded = false;
  particles = [];
  smoke = [];
  shockwaves = [];
  countdownEl.classList.add("hidden");
  finalMessage.classList.add("hidden");
  statusText.textContent = "Sistema listo";
}

startBtn.addEventListener("click", startSequence);
resetBtn.addEventListener("click", resetScene);

animate();
